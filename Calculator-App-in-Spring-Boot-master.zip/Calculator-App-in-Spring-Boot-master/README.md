# Calculator-App-in-Spring-Boot

This is a calculator web application developed using Spring Boot..

This application has functions like Add, Subtract, Multiply, Divide and exponent. 

